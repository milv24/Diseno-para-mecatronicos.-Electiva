*PADS-LIBRARY-SCH-DECALS-V9*

B72210S1140K501         32000 32000 100 10 100 10 4 2 0 2 24
TIMESTAMP 2018.08.29.18.02.15
"Default Font"
"Default Font"
550   250   0 8 100 10 "Default Font"
REF-DES
550   150   0 8 100 10 "Default Font"
PART-TYPE
350   -150  0 12 100 10 "Default Font"
*
350   -250  0 12 100 10 "Default Font"
*
CLOSED 5 10 0 -1
200   50   
500   50   
500   -50  
200   -50  
200   50   
OPEN   4 10 0 -1
150   -100 
250   -100 
450   100  
550   100  
T0     0     0 0 0     10    0 0 0     -10   0 32 PIN
P-520  0     0 2 -80   0     0 2 0
T700   0     0 2 0     10    0 0 0     -10   0 32 PIN
P-520  0     0 2 -80   0     0 2 0


*END*
